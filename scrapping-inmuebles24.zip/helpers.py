import re

regex = r"[-+]?(?:\d*\.\d+|\d+)"

class Inmuebles24(object):
  precio = 0
  propiedad = ''
  tipo = ''
  visualizaciones = 0
  metros_total = 0
  metros_construido = 0
  banos = 0
  medio_banos = 0
  estacionamientos = 0
  recamaras = 0
  antiguedad = 0
  tiempo_de_publicacion = ''
  status_desarrollo = ''

  def __init__(self):
    self.precio = 0
    self.propiedad = ''
    self.tipo = ''
    self.visualizaciones = 0
    self.metros_total = 0
    self.metros_construido = 0
    self.banos = 0
    self.medio_banos = 0
    self.estacionamientos = 0
    self.recamaras = 0
    self.antiguedad = 0
    self.tiempo_de_publicacion = ''
    self.status_desarrollo = ''

def get_number_from_string(string: str, return_zero: bool = False):
  if string:
    # number_list = list(filter(str.isdigit, string.strip()))
    number_list = re.findall(regex, string)
    number = ''.join(number_list)

    if is_int(number):
      return int(number)
    elif is_float(number):
      return float(number)
  
  return 0 if return_zero else None

def is_float(value):
  try:
    float(value)
    return True
  except:
    return False

def is_int(value):
  try:
    int(value)
    return True
  except:
    return False

  
def get_data(soup):
  article_container = soup.find('div', id='article-container')
  title_container = article_container.find('hgroup', class_='title-container')
  user_views_container = article_container.find('div', id='user-views')

  # Data

  datos = Inmuebles24()

  # Price

  price_element = article_container.find('div', class_='price-container').find('div', class_='price-items')
  if price_element:
    datos.precio = get_number_from_string(price_element.text)

  # Title

  title_element = title_container.find('div', class_='section-title')

  if title_element:
    datos.propiedad = title_element.text.strip()

  # Views

  views_element = user_views_container.find('div').find_all('div')[-1]

  if views_element:
    datos.visualizaciones = get_number_from_string(views_element.text)


  # M2 total

  feature_elements = title_container.find('ul', class_='section-icon-features').find_all('li', class_='icon-feature')

  if feature_elements:
    datos.metros_total = get_number_from_string(feature_elements[0].text)

    # If it's not a "Terreno"
    if len(feature_elements) > 1:
      datos.metros_construido = get_number_from_string(feature_elements[1].text)
      datos.antiguedad = get_number_from_string(feature_elements[-1].text, True)
      for element in feature_elements[2:]:
        text = element.text
        if 'Medio baño' in text:
          datos.medio_banos = get_number_from_string(text, True)
        elif 'Baño' in text:
          datos.banos = get_number_from_string(text, True)
        elif 'Estacionamiento' in text:
          datos.estacionamientos = get_number_from_string(text, True)
        elif 'Recámara' in text:
          datos.recamaras = get_number_from_string(text, True)


  # Published date

  date_element = user_views_container.find('div').find_all('div')[0]

  if date_element:
    datos.tiempo_de_publicacion = date_element.text.strip()

  # Tipo de propiedad

  type_element = article_container.find('h2', class_='title-type-sup')

  if type_element:
    datos.tipo = type_element.text.split('·')[0].strip()

  # Status de desarrollo

  status_element = article_container.find('div', class_='price-operation')

  if status_element:
    datos.status_desarrollo = status_element.text.strip()

  return datos