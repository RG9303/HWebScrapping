from array import array
from time import sleep
from bs4 import BeautifulSoup as bs
import pandas as pd
from selenium.webdriver.common.by import By
from undetected_chromedriver import Chrome
import os
import json
import numpy as np

import helpers as hp

base_url = "https://www.inmuebles24.com"
base_path = "inmuebles-en-venta-en-pachuca"
ext = ".html"
url_wo_ext = f"{base_url}/{base_path}"
url = f"{url_wo_ext}{ext}"
filename = "Inmuebles24.csv"
    
datos_de_viviendas = []
viviendas_erroneas = []
urls = []

driver = Chrome(use_subprocess=True)

driver.get(url)
house_container = driver.find_element(By.CLASS_NAME, "postings-container")

for i in range(0, 500):
  places = []

  try:
    places = house_container.find_elements(By.XPATH, "//div[contains(@data-qa, 'PROPERTY')]")
  except:
    print("No more houses in this page")

  print(places)

  for place in places:
    property_url = base_url + place.get_attribute("data-to-posting")
    print(property_url)
    urls.append(property_url)

  next_button = None

  try:
    next_button = driver.find_element(By.CSS_SELECTOR, '[data-qa="PAGING_NEXT"]')
  except:
    print("No Next page button found, finishing scrapping")

  if not next_button:
    break

  next_button.click()
  sleep(5)

driver.close()

driver2 = Chrome(use_subprocess=True)

np_urls = np.array(urls)
chunks = np.array_split(np_urls, 20)

for chunk in chunks:
  datos_de_viviendas = []
  for url in chunk:
    driver.get(url)

    soup = bs(driver.page_source, 'html.parser')

    try:
      inmuebles = hp.get_data(soup)
      datos_de_viviendas.append(inmuebles)
    except:
      print(f"Error trying to get data from: {url}")
      viviendas_erroneas.append(url)

  df = pd.DataFrame([vars(vivienda) for vivienda in datos_de_viviendas])

  if not os.path.isfile(filename):
    df.to_csv(filename, index=False)
  else:
    df.to_csv(filename, mode='a', header=False, index=False)

driver.close()

with open('data.json', 'w') as f:
  json.dump(viviendas_erroneas, f)